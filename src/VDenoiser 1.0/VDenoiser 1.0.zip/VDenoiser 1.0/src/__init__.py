"""
Voice Denoising Engine Abstraction Layer and Reference Implementation.
"""

from src.engine_interface import (
    AudioDenoiseEngine,
    EngineError,
    EngineInitializationError,
    EngineMetadata,
    EngineNotFoundError,
    EngineProcessingError,
    EngineRegistry,
    EngineValidationError,
    FileProcessResult,
    StreamChunkResult,
    get_engine,
    list_available_engines,
    register_engine,
)
from src.mock_engine import MockDenoiseEngine, MockStreamState
from src.audio_io import (
    AudioValidationError,
    chunk_audio,
    downmix_to_mono,
    generate_spectrogram,
    inspect_and_prepare_audio,
    reconstruct_audio_ola,
    resample_audio,
    save_audio_wav,
    summarize_timing,
)

from src.theme import (
    AudioWorkstationTheme,
    DAW_CUSTOM_CSS,
    get_daw_theme,
)

__all__ = [
    "AudioDenoiseEngine",
    "EngineRegistry",
    "get_engine",
    "list_available_engines",
    "register_engine",
    "FileProcessResult",
    "StreamChunkResult",
    "EngineMetadata",
    "EngineError",
    "EngineNotFoundError",
    "EngineInitializationError",
    "EngineProcessingError",
    "EngineValidationError",
    "MockDenoiseEngine",
    "MockStreamState",
    "AudioValidationError",
    "chunk_audio",
    "downmix_to_mono",
    "generate_spectrogram",
    "inspect_and_prepare_audio",
    "reconstruct_audio_ola",
    "resample_audio",
    "save_audio_wav",
    "summarize_timing",
    "AudioWorkstationTheme",
    "DAW_CUSTOM_CSS",
    "get_daw_theme",
]
