"""
src/engine_interface.py - Standard Audio Denoising Engine Interface & Registry.

This module establishes the Layer 1 abstraction boundary for the Audio Denoising
system. It defines:
1. Standard exception hierarchy (EngineError and specialized subclasses).
2. Data Transfer Objects (FileProcessResult, StreamChunkResult, EngineMetadata).
3. AudioDenoiseEngine Abstract Base Class (Contract CT-02).
4. Thread-safe EngineRegistry for plug-and-play factory instantiation.
5. 1-line configuration switcher via environment variable DENOISE_ENGINE.

Strict architectural rule: This module MUST NOT import PyTorch, ONNX, or any
deep learning runtime libraries.
"""

from __future__ import annotations

import abc
import importlib
import logging
import os
import threading
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple, Type

import numpy as np

logger = logging.getLogger(__name__)

# ==============================================================================
# 1. EXCEPTION HIERARCHY
# ==============================================================================

class EngineError(Exception):
    """Base exception for all audio denoise engine errors."""
    def __init__(self, message: str, engine_name: Optional[str] = None):
        self.engine_name = engine_name
        prefix = f"[{engine_name}] " if engine_name else ""
        super().__init__(f"{prefix}{message}")


class EngineNotFoundError(EngineError, KeyError):
    """Raised when an unregistered engine identifier is requested from EngineRegistry."""
    def __init__(self, engine_name: str, available_engines: Optional[List[str]] = None):
        avail_str = f" Available engines: {sorted(available_engines)}" if available_engines else ""
        super().__init__(
            f"Engine '{engine_name}' not found in registry.{avail_str}",
            engine_name=engine_name,
        )


class EngineInitializationError(EngineError):
    """Raised when an engine fails during initialize() or is missing dependencies."""
    def __init__(self, message: str, engine_name: Optional[str] = None, cause: Optional[Exception] = None):
        super().__init__(message, engine_name=engine_name)
        self.cause = cause


class EngineProcessingError(EngineError):
    """Raised when an error occurs during file or stream chunk processing."""
    def __init__(self, message: str, engine_name: Optional[str] = None, is_streaming: bool = False):
        super().__init__(message, engine_name=engine_name)
        self.is_streaming = is_streaming


class EngineValidationError(EngineError, ValueError):
    """Raised when input parameters (audio array, sample rate, paths) violate preconditions."""
    def __init__(self, message: str, engine_name: Optional[str] = None):
        super().__init__(message, engine_name=engine_name)


# ==============================================================================
# 2. DATA TRANSFER OBJECTS (DTOs)
# ==============================================================================

@dataclass(frozen=True)
class FileProcessResult(Mapping):
    """
    Immutable result DTO returned by AudioDenoiseEngine.process_file().

    Implements the Mapping protocol for backward-compatibility with Contract CT-02
    dict consumers:
        result['status'], result['output_path'], result['metrics']
    while also supporting clean attribute access:
        result.status, result.output_path, result.metrics
    """
    status: str = "success"
    output_path: str = ""
    metrics: Dict[str, Any] = field(default_factory=dict)
    message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert DTO into a standard serializable dictionary."""
        return {
            "status": self.status,
            "output_path": self.output_path,
            "metrics": dict(self.metrics),
            "message": self.message,
        }

    # Mapping protocol implementation
    def __getitem__(self, key: str) -> Any:
        d = self.to_dict()
        if key not in d:
            raise KeyError(f"Key '{key}' not in FileProcessResult")
        return d[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self.to_dict())

    def __len__(self) -> int:
        return len(self.to_dict())


@dataclass(frozen=True)
class StreamChunkResult:
    """
    Result DTO for streaming chunk inference.
    """
    chunk: np.ndarray
    sample_rate: int
    state: Any
    latency_ms: float = 0.0

    def to_tuple(self) -> Tuple[np.ndarray, Any]:
        """Return the standard (cleaned_chunk, new_state) tuple."""
        return self.chunk, self.state


@dataclass(frozen=True)
class EngineMetadata:
    """
    Descriptive metadata for registered engines.
    """
    name: str
    display_name: str
    version: str
    description: str
    supported_sample_rates: List[int] = field(default_factory=lambda: [48000])
    requires_gpu: bool = False
    is_available: bool = True
    unavailable_reason: Optional[str] = None


# ==============================================================================
# 3. ABSTRACT BASE CLASS: AudioDenoiseEngine
# ==============================================================================

class AudioDenoiseEngine(abc.ABC):
    """
    Abstract Base Class defining the canonical contract for all Audio Denoising Engines.

    All engine implementations (Mock, DeepFilterNet2, RNNoise, Demucs) must subclass
    AudioDenoiseEngine and implement process_file and process_stream_chunk.
    """

    def __init__(self, **kwargs: Any) -> None:
        self._is_initialized: bool = False
        self._init_kwargs: Dict[str, Any] = kwargs

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """
        Unique lowercase identifier for the engine (e.g. 'mock', 'dfnet2').
        """
        pass

    @property
    def description(self) -> str:
        """Human-readable description of the engine."""
        return self.__doc__ or f"{self.name} audio denoise engine"

    @property
    def supported_sample_rates(self) -> List[int]:
        """List of sample rates supported natively by the engine. Default is [48000]."""
        return [48000]

    @property
    def is_initialized(self) -> bool:
        """Indicates whether initialize() has completed successfully."""
        return self._is_initialized

    def initialize(self, **kwargs: Any) -> None:
        """
        Initialize the engine (allocate buffers, warm up models, verify dependencies).
        This method is idempotent: calling it multiple times has no side effects.
        """
        self._is_initialized = True

    @abc.abstractmethod
    def process_file(self, input_path: str, output_path: str) -> Dict[str, Any]:
        """
        Process a full audio file synchronously (Contract CT-02).

        Args:
            input_path: Path to the input audio file (WAV 48kHz Mono).
            output_path: Target path for the enhanced WAV output.

        Returns:
            Dict or FileProcessResult containing 'status', 'output_path', and 'metrics'.

        Raises:
            EngineValidationError: If input_path does not exist or paths are invalid.
            EngineProcessingError: If processing or file I/O fails.
        """
        pass

    @abc.abstractmethod
    def process_stream_chunk(
        self,
        chunk: np.ndarray,
        sample_rate: int,
        state: Optional[Any] = None,
    ) -> Tuple[np.ndarray, Any]:
        """
        Process a single real-time audio chunk (Contract CT-02 Streaming).

        Args:
            chunk: 1D NumPy array of audio samples (float32).
            sample_rate: Audio sampling rate (e.g. 48000).
            state: Filter state / memory from previous chunk (None for the first chunk).

        Returns:
            Tuple[np.ndarray, Any]:
                - Cleaned audio chunk (1D float32 array).
                - Updated state object for the next streaming chunk.

        Raises:
            EngineValidationError: If chunk shape, type, or sample_rate is unsupported.
            EngineProcessingError: If chunk inference fails.
        """
        pass

    def reset_stream_state(self) -> Any:
        """
        Return a fresh, empty state object for starting a new streaming session.
        Default implementation returns None.
        """
        return None

    def validate_stream_chunk(
        self,
        chunk: np.ndarray,
        sample_rate: int,
    ) -> np.ndarray:
        """
        Defensive helper method for streaming chunk validation and normalization.
        Converts multi-channel to mono and casts to float32 in [-1.0, 1.0].
        """
        if chunk is None or not isinstance(chunk, np.ndarray):
            raise EngineValidationError("Streaming chunk must be a non-null NumPy ndarray", engine_name=self.name)

        if sample_rate <= 0:
            raise EngineValidationError(
                f"Invalid sample rate: {sample_rate}. Must be positive.",
                engine_name=self.name,
            )

        if not np.issubdtype(chunk.dtype, np.number):
            raise EngineValidationError(
                f"Unsupported chunk dtype '{chunk.dtype}'. Audio chunk must be a numeric array.",
                engine_name=self.name,
            )

        # Downmix multi-channel to mono if necessary before size check
        if chunk.ndim > 1:
            chunk = np.mean(chunk, axis=-1)

        if chunk.ndim == 0:
            chunk = chunk.reshape(-1)

        if chunk.size == 0:
            return chunk.astype(np.float32)

        # Convert integer formats to float32 [-1.0, 1.0]
        try:
            if np.issubdtype(chunk.dtype, np.integer):
                max_val = float(np.iinfo(chunk.dtype).max)
                chunk = (chunk.astype(np.float32) / max_val)
            elif chunk.dtype != np.float32:
                chunk = chunk.astype(np.float32)
        except (ValueError, TypeError) as exc:
            raise EngineValidationError(
                f"Failed to convert chunk dtype '{chunk.dtype}' to float32: {exc}",
                engine_name=self.name,
            ) from exc

        # Sanitize NaN/Inf to prevent filter state corruption
        if not np.all(np.isfinite(chunk)):
            chunk = np.nan_to_num(chunk, copy=False, nan=0.0, posinf=1.0, neginf=-1.0)

        # Check sample rate compatibility
        if sample_rate not in self.supported_sample_rates:
            logger.warning(
                "[%s] Sample rate %d Hz not in supported rates %s; performance may degrade.",
                self.name, sample_rate, self.supported_sample_rates
            )

        return chunk

    def __enter__(self) -> AudioDenoiseEngine:
        if not self.is_initialized:
            self.initialize(**self._init_kwargs)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass


# ==============================================================================
# 4. ENGINE REGISTRY & FACTORY
# ==============================================================================

class EngineRegistry:
    """
    Thread-safe registry and factory for AudioDenoiseEngine implementations.

    Supports:
    - Decorator-based class registration: @EngineRegistry.register('mock')
    - Lazy-loading registration via module import path
    - Instance caching for low-latency reuse across UI events
    - 1-line configuration switching via environment variable DENOISE_ENGINE
    """

    _lock: threading.RLock = threading.RLock()
    _registry: Dict[str, Type[AudioDenoiseEngine]] = {}
    _lazy_registry: Dict[str, str] = {}  # key -> 'module.submodule.ClassName'
    _aliases: Dict[str, str] = {}        # alias -> canonical_key
    _instances: Dict[str, AudioDenoiseEngine] = {}

    @classmethod
    def register(
        cls,
        name: str,
        aliases: Optional[List[str]] = None,
        force: bool = False,
    ) -> Callable[[Type[AudioDenoiseEngine]], Type[AudioDenoiseEngine]]:
        """
        Decorator to register an AudioDenoiseEngine subclass.
        """
        def decorator(subclass: Type[AudioDenoiseEngine]) -> Type[AudioDenoiseEngine]:
            cls.register_class(name, subclass, aliases=aliases, force=force)
            return subclass
        return decorator

    @classmethod
    def register_class(
        cls,
        name: str,
        engine_cls: Type[AudioDenoiseEngine],
        aliases: Optional[List[str]] = None,
        force: bool = False,
    ) -> None:
        """Register an engine class directly under a canonical name."""
        with cls._lock:
            canonical = name.strip().lower()
            if not issubclass(engine_cls, AudioDenoiseEngine):
                raise TypeError(f"Class '{engine_cls.__name__}' must inherit from AudioDenoiseEngine")
            if canonical in cls._registry and not force:
                logger.debug("Engine '%s' already registered, skipping.", canonical)
                return

            if aliases:
                for alias in aliases:
                    alias_clean = alias.strip().lower()
                    if (alias_clean in cls._registry or alias_clean in cls._lazy_registry) and not force:
                        raise ValueError(f"Alias '{alias_clean}' collides with canonical engine name")

            cls._registry[canonical] = engine_cls
            cls._lazy_registry.pop(canonical, None)

            if aliases:
                for alias in aliases:
                    alias_clean = alias.strip().lower()
                    cls._aliases[alias_clean] = canonical

            logger.info("Registered engine '%s' (%s)", canonical, engine_cls.__name__)

    @classmethod
    def register_lazy(
        cls,
        name: str,
        import_path: str,
        aliases: Optional[List[str]] = None,
        force: bool = False,
    ) -> None:
        """
        Register an engine by its module import path without importing it immediately.
        Enables zero startup import overhead for heavy AI engines.
        """
        with cls._lock:
            canonical = name.strip().lower()
            if canonical in cls._registry and not force:
                return

            if aliases:
                for alias in aliases:
                    alias_clean = alias.strip().lower()
                    if (alias_clean in cls._registry or alias_clean in cls._lazy_registry) and not force:
                        raise ValueError(f"Alias '{alias_clean}' collides with canonical engine name")

            cls._lazy_registry[canonical] = import_path
            if aliases:
                for alias in aliases:
                    alias_clean = alias.strip().lower()
                    cls._aliases[alias_clean] = canonical

            logger.debug("Lazily registered engine '%s' -> '%s'", canonical, import_path)

    @classmethod
    def _resolve_canonical_name(cls, name: str) -> str:
        """Resolve an engine name or alias to its canonical key."""
        clean = name.strip().lower()
        return cls._aliases.get(clean, clean)

    @classmethod
    def _load_lazy_engine(cls, canonical: str) -> Type[AudioDenoiseEngine]:
        """Dynamically import and register a lazy engine."""
        import_path = cls._lazy_registry[canonical]
        module_path, class_name = import_path.rsplit(".", 1)
        try:
            mod = importlib.import_module(module_path)
            engine_cls = getattr(mod, class_name)
            if not issubclass(engine_cls, AudioDenoiseEngine):
                raise TypeError(f"Target '{import_path}' does not inherit from AudioDenoiseEngine")
            cls._registry[canonical] = engine_cls
            return engine_cls
        except Exception as exc:
            raise EngineInitializationError(
                f"Failed to load lazy engine '{canonical}' from '{import_path}': {exc}",
                engine_name=canonical,
                cause=exc,
            ) from exc

    @classmethod
    def get_engine_class(cls, name: str) -> Type[AudioDenoiseEngine]:
        """
        Retrieve the engine class for the given name or alias.
        """
        with cls._lock:
            if not name or not name.strip():
                raise EngineNotFoundError(name or "", available_engines=cls.list_available_engines())

            canonical = cls._resolve_canonical_name(name)
            if canonical in cls._registry:
                return cls._registry[canonical]
            if canonical in cls._lazy_registry:
                return cls._load_lazy_engine(canonical)

            raise EngineNotFoundError(name, available_engines=cls.list_available_engines())

    @classmethod
    def get_engine(
        cls,
        name: Optional[str] = None,
        cache_instance: bool = True,
        **kwargs: Any,
    ) -> AudioDenoiseEngine:
        """
        Factory function returning an initialized AudioDenoiseEngine instance.

        If name is None, resolves the engine name in priority order:
        1. Environment variable DENOISE_ENGINE
        2. Fallback default: 'mock'
        """
        with cls._lock:
            if name is None:
                name = os.environ.get("DENOISE_ENGINE", "mock")

            if not name or not name.strip():
                raise EngineNotFoundError(name or "", available_engines=cls.list_available_engines())

            canonical = cls._resolve_canonical_name(name)

            if cache_instance and canonical in cls._instances and not kwargs:
                inst = cls._instances[canonical]
                if not inst.is_initialized:
                    inst.initialize()
                return inst

            engine_cls = cls.get_engine_class(canonical)
            try:
                instance = engine_cls(**kwargs)
                instance.initialize()
            except Exception as exc:
                if isinstance(exc, EngineError):
                    raise
                raise EngineInitializationError(
                    f"Initialization of engine '{canonical}' failed: {exc}",
                    engine_name=canonical,
                    cause=exc,
                ) from exc

            if cache_instance and not kwargs:
                cls._instances[canonical] = instance

            return instance

    @classmethod
    def list_available_engines(cls) -> List[str]:
        """Return a sorted list of all registered canonical engine keys."""
        with cls._lock:
            all_keys = set(cls._registry.keys()).union(cls._lazy_registry.keys())
            return sorted(all_keys)

    @classmethod
    def unregister(cls, name: str) -> None:
        """Unregister an engine and clear its cached instance."""
        with cls._lock:
            canonical = cls._resolve_canonical_name(name)
            cls._registry.pop(canonical, None)
            cls._lazy_registry.pop(canonical, None)
            cls._instances.pop(canonical, None)
            # Remove any aliases pointing to canonical
            cls._aliases = {k: v for k, v in cls._aliases.items() if v != canonical}

    @classmethod
    def clear(cls) -> None:
        """Reset all registries and instances (used primarily in test fixtures)."""
        with cls._lock:
            cls._registry.clear()
            cls._lazy_registry.clear()
            cls._aliases.clear()
            cls._instances.clear()
            cls._register_defaults()

    @classmethod
    def _register_defaults(cls) -> None:
        """Register standard engine keys and lazy pathways."""
        # 1. Mock engine (CPU pass-through & DSP filtering)
        cls.register_lazy("mock", "src.mock_engine.MockDenoiseEngine", aliases=["passthrough", "mock_dsp"])
        # 2. DeepFilterNet2 full-band engine
        cls.register_lazy("dfnet2", "src.dfnet_engine.DeepFilterNetEngine", aliases=["deepfilter", "df2"])
        # 3. RNNoise recurrent engine
        cls.register_lazy("rnnoise", "src.rnnoise_engine.RNNoiseEngine", aliases=["rnn"])
        # 4. Demucs waveform enhancement engine
        cls.register_lazy("demucs", "src.demucs_engine.DemucsEngine", aliases=["htdemucs"])


# Initialize standard defaults upon module import
EngineRegistry._register_defaults()


# ==============================================================================
# 5. GLOBAL CONVENIENCE HELPERS (1-Line Engine Switching)
# ==============================================================================

def get_engine(name: Optional[str] = None, **kwargs: Any) -> AudioDenoiseEngine:
    """
    Global factory helper for 1-line engine loading:
        engine = get_engine()
        engine = get_engine('mock')
        engine = get_engine('dfnet2')
    """
    return EngineRegistry.get_engine(name=name, **kwargs)


def list_available_engines() -> List[str]:
    """Return all available engine keys."""
    return EngineRegistry.list_available_engines()


def register_engine(
    name: str,
    aliases: Optional[List[str]] = None,
    force: bool = False,
) -> Callable[[Type[AudioDenoiseEngine]], Type[AudioDenoiseEngine]]:
    """Decorator to register an engine class."""
    return EngineRegistry.register(name, aliases=aliases, force=force)
